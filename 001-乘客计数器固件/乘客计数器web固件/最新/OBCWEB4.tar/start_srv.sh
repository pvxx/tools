
set -e
/opt/apc/bin/time
#ifconfig eth1 10.0.0.3
#ifconfig eth0:0 10.0.0.3
/opt/apc/bin/ipset
/opt/apc/bin/init_gpio
/opt/apc/bin/monitor_apc &
/opt/apc/bin/monitor_pwr &
/opt/apc/bin/rpis_connect &
/opt/apc/bin/httpd -p 8001 -h /opt/apc/bin/web_portu &
cat /opt/apc/bin/lan | while read line
do
if [ "$line" == "1" ];
then                
        killall httpd    
        /opt/apc/bin/httpd -p 8001 -h /opt/apc/bin/web_portu &
fi

done


